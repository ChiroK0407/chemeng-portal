import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useOpportunities, useBookmarkOpportunity } from '../../hooks/useOpportunities';
import { useAuth } from '../../context/AuthContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { 
  Search, Briefcase, MapPin, Calendar, Bookmark, 
  Filter, Building, DollarSign, SlidersHorizontal 
} from 'lucide-react';

const TAB_OPTIONS = [
  { label: 'All Openings', value: 'all' },
  { label: 'Internships', value: 'internship' },
  { label: 'Full-time Roles', value: 'full_time' },
  { label: 'Research Tracks', value: 'research' },
  { label: 'Fellowships', value: 'fellowship' }
];

export default function OpportunitiesPage() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const bookmarkMutation = useBookmarkOpportunity();

  const [activeTab, setActiveTab] = useState(searchParams.get('type') || 'all');
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [isRemote, setIsRemote] = useState(searchParams.get('isRemote') === 'true');
  const [location, setLocation] = useState(searchParams.get('location') || '');
  const [minStipend, setMinStipend] = useState(searchParams.get('minStipend') || '');
  const [branch, setBranch] = useState(searchParams.get('branch') || '');
  const [showOnlyOpen, setShowOnlyOpen] = useState(searchParams.get('showOnlyOpen') !== 'false');
  const [sortBy, setSortBy] = useState(searchParams.get('sortBy') || 'latest');
  const [limit, setLimit] = useState(10);
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);

  const debouncedSearch = useDebounce(search, 300);
  const debouncedLocation = useDebounce(location, 300);
  const debouncedBranch = useDebounce(branch, 300);

  useEffect(() => {
    const params: Record<string, string> = {};
    if (activeTab !== 'all') params.type = activeTab;
    if (debouncedSearch) params.search = debouncedSearch;
    if (isRemote) params.isRemote = 'true';
    if (debouncedLocation) params.location = debouncedLocation;
    if (minStipend) params.minStipend = minStipend;
    if (debouncedBranch) params.branch = debouncedBranch;
    if (!showOnlyOpen) params.showOnlyOpen = 'false';
    if (sortBy !== 'latest') params.sortBy = sortBy;
    setSearchParams(params);
  }, [activeTab, debouncedSearch, isRemote, debouncedLocation, minStipend, debouncedBranch, showOnlyOpen, sortBy, setSearchParams]);

  const { data, isLoading, isError } = useOpportunities({
    page: 1,
    limit,
    type: activeTab !== 'all' ? activeTab : undefined,
    search: debouncedSearch || undefined,
    isRemote: isRemote || undefined,
    location: debouncedLocation || undefined,
    minStipend: minStipend ? Number(minStipend) : undefined,
    branch: debouncedBranch || undefined,
    showOnlyOpen,
    sortBy
  });

  const listings = data?.data || (Array.isArray(data) ? data : []);
  const meta = data?.meta;

  // ✅ FIXED: Standardized filtration matching cascade across mixed enums configurations 
  const filteredListings = listings.filter((opp: any) => {
    const opportunityType = String(opp.type || '').toLowerCase().replace('-', '_');
    return activeTab === 'all' || activeTab === opportunityType;
  });

  const hasMore = meta ? filteredListings.length < meta.total : false;

  const getDeadlineMetadata = (deadlineStr: string) => {
    if (!deadlineStr) return { text: 'No Deadline', colorClass: 'text-surface-400 bg-surface-100 dark:bg-surface-800' };
    const targetDate = new Date(deadlineStr);
    const today = new Date();
    const diffTime = targetDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { text: 'Expired', colorClass: 'text-surface-400 bg-surface-100 dark:bg-surface-800' };
    if (diffDays <= 3) return { text: `${diffDays} days left`, colorClass: 'text-red-600 bg-red-50 dark:bg-red-950/30' };
    if (diffDays <= 14) return { text: `${diffDays} days left`, colorClass: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30' };
    return { text: `${diffDays} days left`, colorClass: 'text-green-600 bg-green-50 dark:bg-green-950/30' };
  };

  const SidebarFilters = () => (
    <div className="space-y-5">
      <div>
        <label className="text-xs font-bold uppercase tracking-wider text-surface-400">Keyword Search</label>
        <div className="relative mt-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
          <input type="text" placeholder="Search role..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl text-sm" />
        </div>
      </div>
      <div className="flex items-center justify-between p-3 bg-surface-50 dark:bg-surface-950 rounded-xl border border-surface-200 dark:border-surface-800">
        <span className="text-xs font-semibold">Remote Only</span>
        <input type="checkbox" checked={isRemote} onChange={(e) => setIsRemote(e.target.checked)} className="w-4 h-4 rounded text-[#1a63ef]" />
      </div>
      <div>
        <label className="text-xs font-bold uppercase tracking-wider text-surface-400">Location</label>
        <input type="text" placeholder="e.g. Mumbai" value={location} onChange={(e) => setLocation(e.target.value)} className="w-full mt-1 p-2.5 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl text-sm" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-950 pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-4 border-b border-surface-200 dark:border-surface-800 gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-surface-900 dark:text-white">Opportunities</h1>
            <p className="text-sm text-surface-500 mt-0.5">Explore curated corporate internships, full-time openings, and fellowship channels.</p>
          </div>
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="px-4 py-2 bg-white dark:bg-surface-900 border border-surface-200 rounded-xl text-sm font-semibold">
            <option value="latest">Latest Posted</option>
            <option value="deadline">Soonest Deadline</option>
          </select>
        </div>

        <div className="flex overflow-x-auto gap-1 pb-2 mb-6 border-b border-surface-100 dark:border-surface-800 scrollbar-hide">
          {TAB_OPTIONS.map(opt => (
            <button key={opt.value} onClick={() => setActiveTab(opt.value)} className={`px-4 py-2 text-sm font-semibold whitespace-nowrap border-b-2 ${activeTab === opt.value ? 'border-[#1a63ef] text-[#1a63ef]' : 'border-transparent text-surface-500'}`}>{opt.label}</button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 items-start">
          <aside className="hidden md:block bg-white dark:bg-surface-900 p-6 rounded-2xl border border-surface-200 dark:border-surface-800 shadow-sm"><SidebarFilters /></aside>

          <div className="md:col-span-3 space-y-4">
            {isLoading ? (
              <div className="space-y-4">{[...Array(3)].map((_, i) => <div key={i} className="h-32 bg-surface-200 dark:bg-surface-800 rounded-2xl animate-pulse" />)}</div>
            ) : filteredListings.length === 0 ? (
              <EmptyState title="No Openings Tracked" description="No active listings match your current filter parameters." />
            ) : (
              <div className="space-y-4">
                {filteredListings.map((opp: any) => {
                  const dlMeta = getDeadlineMetadata(opp.deadline);
                  return (
                    <Card key={opp.id} className="p-5 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 rounded-2xl shadow-sm flex flex-col sm:flex-row items-start justify-between gap-5 relative">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center font-bold text-white shadow-inner shrink-0">{opp.company.substring(0,2).toUpperCase()}</div>
                        <div>
                          <h3 className="font-bold text-lg text-surface-900 dark:text-white">{opp.title}</h3>
                          <p className="text-sm font-semibold text-surface-500 flex items-center gap-1"><Building className="w-3.5 h-3.5" /> {opp.company}</p>
                          <div className="flex flex-wrap gap-4 text-xs text-surface-400 mt-2">
                            <span><MapPin className="w-3.5 h-3.5 inline mr-1" />{opp.location}</span>
                            <span><DollarSign className="w-3.5 h-3.5 inline mr-1" />{opp.stipendMin ? `₹${opp.stipendMin.toLocaleString()} - ₹${opp.stipendMax.toLocaleString()}` : 'Disclosed on Interview'}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex sm:flex-col items-end gap-4 w-full sm:w-auto pt-4 sm:pt-0 border-t sm:border-t-0 border-surface-100 dark:border-surface-800">
                        <span className={`px-2.5 py-1 text-xs font-bold rounded-full ${dlMeta.colorClass}`}>{dlMeta.text}</span>
                        <a href={opp.applyUrl || '#'} target="_blank" rel="noreferrer"><Button size="sm" className="bg-[#1a63ef] text-white rounded-xl">Apply Profile</Button></a>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}