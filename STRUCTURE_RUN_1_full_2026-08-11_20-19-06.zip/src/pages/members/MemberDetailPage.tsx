import { useParams, Link } from 'react-router-dom';
import { useMember } from '../../hooks/useMembers';
import { Spinner } from '../../components/ui/Spinner';
import { Badge } from '../../components/ui/Badge';
import { Card } from '../../components/ui/Card';
// ✅ REMOVED: Broken brand entries removed from lucide-react destructuring imports
import { ArrowLeft, Globe, GraduationCap, FlaskConical, BookOpen, Clock, Award } from 'lucide-react';

export default function MemberDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { data: member, isLoading, isError } = useMember(id || '');

  if (isLoading) return <Spinner />;
  
  if (isError || !member) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-50 dark:bg-surface-950 px-4">
        <div className="text-center max-w-sm card p-6 border border-surface-200 dark:border-surface-800 rounded-2xl">
          <p className="text-sm text-surface-500">The specific researcher or member directory card is missing or archived.</p>
          <Link to="/members" className="text-blue-600 font-bold mt-4 inline-flex items-center gap-1"><ArrowLeft className="w-4 h-4" /> Return to Members</Link>
        </div>
      </div>
    );
  }

  const profile = member.profile || {};
  const nameStr = profile.fullName || 'Anonymous Member';
  const projects = member.projects || [];
  const blogs = member.blogs || [];

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-950 pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        <Link to="/members" className="inline-flex items-center gap-1.5 text-sm font-semibold text-surface-500 hover:text-blue-600 mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Directory
        </Link>

        {/* Profile Identity Summary Dashboard Card */}
        <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 rounded-3xl p-6 md:p-8 shadow-sm flex flex-col sm:flex-row items-center gap-6 mb-8 text-center sm:text-left relative overflow-hidden">
          <div className="w-20 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-700 flex items-center justify-center font-bold text-white text-2xl flex-shrink-0 shadow-md border-2 border-white dark:border-surface-800">
            {profile.avatarUrl ? <img src={profile.avatarUrl} alt={nameStr} className="w-full h-full object-cover rounded-full" /> : nameStr.substring(0, 2).toUpperCase()}
          </div>
          <div className="flex-1 space-y-2">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
              <h1 className="text-2xl md:text-3xl font-bold text-surface-900 dark:text-white leading-none">{nameStr}</h1>
              <Badge className="text-[10px] uppercase font-bold tracking-wide rounded mt-1.5 bg-surface-50 dark:bg-surface-800 text-surface-600 dark:text-surface-300 border-none px-2 py-0.5">{member.role}</Badge>
            </div>
            <p className="text-sm font-semibold text-surface-600 dark:text-surface-300 flex items-center justify-center sm:justify-start gap-1"><GraduationCap className="w-4 h-4 text-surface-400" /> {profile.college || 'Academic Affiliate'}</p>
            <p className="text-xs font-medium text-surface-400">{profile.branch || 'Chemical Engineering'} {profile.gradYear ? `• Class of ${profile.gradYear}` : ''}</p>
          </div>

          {/* Social Links Ingestion Anchor Handles Stack */}
          <div className="flex gap-2 text-surface-400 dark:text-surface-500 self-center sm:self-auto pt-2 sm:pt-0">
            {/* 💡 FIXED: Injected embedded vector layout mapping for custom LinkedIn profile links */}
            {profile.linkedinUrl && (
              <a href={profile.linkedinUrl} target="_blank" rel="noreferrer" className="p-2 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl hover:text-blue-600 transition-colors flex items-center justify-center">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                </svg>
              </a>
            )}
            {/* 💡 FIXED: Injected embedded vector layout mapping for custom GitHub repository links */}
            {profile.githubUrl && (
              <a href={profile.githubUrl} target="_blank" rel="noreferrer" className="p-2 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl hover:text-surface-900 dark:hover:text-white transition-colors flex items-center justify-center">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 3.523 1.304 4.381.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
              </a>
            )}
            {profile.websiteUrl && <a href={profile.websiteUrl} target="_blank" rel="noreferrer" className="p-2 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl hover:text-blue-600 transition-colors flex items-center justify-center"><Globe className="w-4 h-4" /></a>}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          <div className="lg:col-span-2 space-y-6">
            
            <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 p-6 rounded-2xl shadow-sm">
              <h3 className="text-sm font-bold text-surface-900 dark:text-white border-b pb-3 mb-4 uppercase tracking-wider">Professional Statement / Abstract</h3>
              <p className="text-sm text-surface-600 dark:text-surface-400 leading-relaxed whitespace-pre-line">
                {profile.bio || 'This member has not composed an academic or career bio synopsis abstract on their credentials engine card yet.'}
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 flex items-center gap-1.5 px-1">
                <FlaskConical className="w-4 h-4 text-[#1a63ef]" /> Research Templates & Process Models ({projects.length})
              </h3>
              {projects.length === 0 ? (
                <div className="p-8 text-center bg-white dark:bg-surface-900 border rounded-2xl border-surface-200 dark:border-surface-800"><p className="text-xs text-surface-400 italic">No public engineering projects compiled under this member index handles.</p></div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {projects.map((proj: any) => (
                    <Link key={proj.id} to={`/projects/${proj.slug}`} className="block card p-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 rounded-xl hover:border-surface-300 dark:hover:border-surface-700 transition-all group">
                      <span className="text-[10px] font-bold text-[#1a63ef] uppercase block tracking-wider mb-1">{proj.category}</span>
                      <h4 className="font-bold text-sm text-surface-900 dark:text-white line-clamp-1 group-hover:text-blue-600 transition-colors">{proj.title}</h4>
                      <p className="text-xs text-surface-400 line-clamp-2 mt-1.5 leading-relaxed">{proj.description}</p>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 flex items-center gap-1.5 px-1">
                <BookOpen className="w-4 h-4 text-purple-500" /> Academic Logs & Publications ({blogs.length})
              </h3>
              {blogs.length === 0 ? (
                <div className="p-8 text-center bg-white dark:bg-surface-900 border rounded-2xl border-surface-200 dark:border-surface-800"><p className="text-xs text-surface-400 italic">No published articles authored under this researcher thread account handle.</p></div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {blogs.map((blog: any) => (
                    <Link key={blog.id} to={`/blogs/${blog.slug}`} className="block card p-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 rounded-xl hover:border-surface-300 dark:hover:border-surface-700 transition-all group">
                      <h4 className="font-bold text-sm text-surface-900 dark:text-white line-clamp-1 group-hover:text-blue-600 transition-colors">{blog.title}</h4>
                      <div className="flex items-center gap-3 text-[11px] text-surface-400 font-semibold mt-3 pt-2 border-t border-surface-100 dark:border-surface-800/40">
                        <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" /> {blog.readTimeMin || 4} min read</span>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

          </div>

          <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 p-6 rounded-2xl shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 flex items-center gap-1.5 mb-4">
              <Award className="w-4 h-4 text-[#1a63ef]" /> Specialized Domain Expertise
            </h3>
            <div className="flex flex-wrap gap-2">
              {profile.skills && profile.skills.length > 0 ? (
                profile.skills.map((skill: string) => (
                  <span key={skill} className="px-3 py-1 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 text-surface-700 dark:text-surface-200 text-xs font-semibold rounded-lg">
                    {skill}
                  </span>
                ))
              ) : (
                <span className="text-xs italic text-surface-400">No explicit skill keywords listed on profile context canvas.</span>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}