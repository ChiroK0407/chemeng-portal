import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useMembers } from '../../hooks/useMembers';
import { useDebounce } from '../../hooks/useDebounce';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
// ✅ REMOVED: Broken brand entries removed from lucide-react destructuring imports
import { Search, GraduationCap, SlidersHorizontal } from 'lucide-react';

const ROLE_FILTERS = [
  { label: 'All Directory', value: 'all' },
  { label: 'Students', value: 'student' },
  { label: 'Alumni Network', value: 'alumni' },
  { label: 'Faculty', value: 'faculty' }
];

export default function MemberListPage() {
  const [search, setSearch] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [limit, setLimit] = useState(12);

  const debouncedSearch = useDebounce(search, 300);

  const { data, isLoading, isError } = useMembers({
    page: 1,
    limit,
    search: debouncedSearch || undefined,
    role: selectedRole !== 'all' ? selectedRole : undefined
  });

  const members = data?.data || [];
  const meta = data?.meta;
  const hasMore = meta ? members.length < meta.total : false;

  const getAvatarFallbackColor = (name: string) => {
    const charCodeSum = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const options = [
      'bg-blue-600 text-blue-50',
      'bg-purple-600 text-purple-50',
      'bg-teal-600 text-teal-50',
      'bg-emerald-600 text-emerald-50',
      'bg-indigo-600 text-indigo-50'
    ];
    return options[charCodeSum % options.length];
  };

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-950 pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-6 border-b border-surface-200 dark:border-surface-800 gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-surface-900 dark:text-white">Community Members</h1>
            <p className="text-sm text-surface-500 mt-1">Connect with Chemical Engineering peers, research investigators, and academic leaders.</p>
          </div>
        </div>

        <div className="bg-white dark:bg-surface-900 p-5 rounded-2xl border border-surface-200 dark:border-surface-800 shadow-sm mb-8 space-y-4">
          <div className="relative w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
            <input
              type="text"
              placeholder="Search by engineer's name, college campus, or core technical skill (e.g. Aspen, MATLAB)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl text-sm dark:text-surface-100 focus:outline-none focus:ring-2 focus:ring-[#1a63ef]"
            />
          </div>

          <div className="flex flex-wrap gap-2 items-center pt-2 border-t border-surface-100 dark:border-surface-800">
            <span className="text-xs font-semibold uppercase tracking-wider text-surface-400 mr-2 flex items-center gap-1">
              <SlidersHorizontal className="w-3.5 h-3.5" /> Filters:
            </span>
            {ROLE_FILTERS.map((role) => (
              <button
                key={role.value}
                onClick={() => setSelectedRole(role.value)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-all ${
                  selectedRole === role.value
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-surface-300 hover:bg-surface-200 dark:hover:bg-surface-700'
                }`}
              >
                {role.label}
              </button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 animate-pulse">
            {[...Array(8)].map((_, i) => <div key={i} className="h-72 bg-surface-200 dark:bg-surface-800 rounded-2xl" />)}
          </div>
        ) : isError || members.length === 0 ? (
          <EmptyState title="No Profiles Indexed" description="No active member directories correspond to your active criteria configurations." />
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {members.map((member: any) => {
                const profile = member.profile || {};
                const nameStr = profile.fullName || 'Anonymous Engineer';
                const colorToken = getAvatarFallbackColor(nameStr);
                
                return (
                  <Card key={member.id} className="p-5 h-full flex flex-col justify-between items-center text-center dark:bg-surface-900 border-surface-200 dark:border-surface-800 rounded-2xl shadow-sm hover:shadow-md transition-all group">
                    <div className="w-full flex flex-col items-center">
                      
                      <div className="relative mb-4">
                        {profile.avatarUrl ? (
                          <img src={profile.avatarUrl} alt={nameStr} className="w-16 h-16 rounded-full object-cover border" />
                        ) : (
                          <div className={`w-16 h-16 rounded-full flex items-center justify-center font-bold text-lg shadow-inner ${colorToken}`}>
                            {nameStr.substring(0, 2).toUpperCase()}
                          </div>
                        )}
                      </div>

                      <h3 className="font-bold text-base text-surface-900 dark:text-white line-clamp-1 group-hover:text-blue-600 transition-colors">{nameStr}</h3>
                      <Badge className="text-[9px] uppercase font-bold tracking-wide rounded mt-1.5 bg-surface-50 dark:bg-surface-800 text-surface-600 dark:text-surface-300 border border-surface-200 dark:border-surface-700 px-2 py-0.5">
                        {member.role}
                      </Badge>

                      <div className="mt-4 space-y-1 text-xs text-surface-400 font-semibold w-full">
                        <p className="flex items-center justify-center gap-1 text-surface-600 dark:text-surface-300 line-clamp-1"><GraduationCap className="w-3.5 h-3.5 flex-shrink-0" /> {profile.college || 'Academic Affiliate'}</p>
                        <p className="text-[11px] font-medium line-clamp-1">{profile.branch || 'Chemical Engineering'} {profile.gradYear ? `• Class of ${profile.gradYear}` : ''}</p>
                      </div>

                      {profile.skills && profile.skills.length > 0 && (
                        <div className="flex flex-wrap justify-center gap-1 mt-4 w-full h-12 overflow-hidden content-start">
                          {profile.skills.slice(0, 3).map((skill: string) => (
                            <span key={skill} className="px-2 py-0.5 text-[10px] font-bold rounded bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800/80 text-surface-500 dark:text-surface-400">
                              {skill}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="w-full mt-5 pt-3 border-t border-surface-100 dark:border-surface-800/60 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 text-surface-400 dark:text-surface-500">
                        {/* 💡 FIXED: Injected standard vector code elements to handle LinkedIn icons directly */}
                        {profile.linkedinUrl && (
                          <a href={profile.linkedinUrl} target="_blank" rel="noreferrer" className="hover:text-blue-600 transition-colors">
                            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                              <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                            </svg>
                          </a>
                        )}
                        {/* 💡 FIXED: Injected standard vector code elements to handle GitHub icons directly */}
                        {profile.githubUrl && (
                          <a href={profile.githubUrl} target="_blank" rel="noreferrer" className="hover:text-surface-800 dark:hover:text-white transition-colors">
                            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 3.523 1.304 4.381.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                            </svg>
                          </a>
                        )}
                      </div>

                      <Link to={`/members/${member.id}`} className="flex-1">
                        <Button variant="outline" className="w-full py-1.5 rounded-xl text-[11px] font-bold">
                          View Profile
                        </Button>
                      </Link>
                    </div>

                  </Card>
                );
              })}
            </div>

            {hasMore && (
              <div className="flex justify-center pt-10">
                <button onClick={() => setLimit(prev => prev + 12)} className="px-5 py-2.5 border border-surface-200 dark:border-surface-800 text-xs font-bold rounded-xl bg-white dark:bg-surface-900 text-surface-700 dark:text-surface-200 shadow-sm hover:bg-surface-50 transition-colors">
                  Load More Members
                </button>
              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
}