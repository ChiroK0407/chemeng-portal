export default function BlogListPage() {
  return (
    <main className="pt-24 container-page section">
      <h1 className="text-3xl font-display font-bold text-gradient mb-2">Blogs</h1>
      <p className="text-surface-500">Full implementation coming in Phase 7.</p>
    </main>
  )
}