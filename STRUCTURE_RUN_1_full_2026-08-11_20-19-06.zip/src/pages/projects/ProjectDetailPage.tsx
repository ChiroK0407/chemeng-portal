import { useParams, Link } from 'react-router-dom';
import { useProject, useProjects } from '@/hooks/useProjects';
import { PageSpinner } from '@/components/ui/Spinner';
import { GitBranch, ExternalLink, Eye, ArrowLeft, Users, Terminal } from 'lucide-react';

export default function ProjectDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data: project, isLoading, isError } = useProject(slug || '');

  // Fetch adjacent contextual entries to satisfy related item grid structures
  const { data: relatedData } = useProjects({
    category: project?.category,
    limit: 3
  });

  if (isLoading) return <PageSpinner />;
  if (isError || !project) {
    return (
      <div className="min-h-screen flex items-center justify-center dark:bg-surface-950">
        <div className="text-center max-w-sm">
          <p className="text-surface-500 mb-4">The simulation template specified is inaccessible or missing.</p>
          <Link to="/projects" className="text-[#1a63ef] font-semibold flex items-center justify-center gap-1.5">
            <ArrowLeft className="w-4 h-4" /> Return to Gallery
          </Link>
        </div>
      </div>
    );
  }

  const relatedProjects = relatedData?.data?.filter((p: any) => p.id !== project.id).slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-950 pb-20">
      
      {/* Immersive Cover Image Hero Display Panel */}
      <div className="relative w-full h-[360px] md:h-[420px] bg-surface-900">
        {project.coverUrl ? (
          <img src={project.coverUrl} alt={project.title} className="w-full h-full object-cover opacity-60" />
        ) : (
          <div className="w-full h-full bg-gradient-to-tr from-surface-900 to-indigo-950 opacity-80" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-surface-50 dark:from-surface-950 to-transparent" />
        
        {/* Absolute Floating Navigation Anchors */}
        <div className="absolute top-6 left-4 sm:left-8 z-10">
          <Link to="/projects" className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 dark:bg-black/40 backdrop-blur-md border border-white/20 rounded-xl text-xs font-semibold text-surface-900 dark:text-white shadow-sm hover:bg-white dark:hover:bg-black/60 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Showcase
          </Link>
        </div>
      </div>

      {/* Main Structural Ingestion Core Container Wrapper */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column Stack: Core Scientific Markup Content */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 p-6 md:p-8 rounded-2xl shadow-sm">
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <span className="px-3 py-1 bg-primary-50 dark:bg-primary-950 border border-primary-200 dark:border-primary-800 text-primary-700 dark:text-primary-300 font-semibold tracking-wide uppercase text-[11px] rounded-md">
                  {project.category}
                </span>
                <span className="text-xs text-surface-400 dark:text-surface-500 font-medium flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" /> {project.views} Abstract Reads
                </span>
              </div>

              <h1 className="text-2xl md:text-3xl font-bold text-surface-900 dark:text-surface-50 leading-tight">
                {project.title}
              </h1>

              {/* Action Key Control Grid Anchors Row Block */}
              <div className="flex flex-wrap gap-3 mt-6 border-b border-surface-100 dark:border-surface-800 pb-6">
                {project.githubUrl && (
                  <a href={project.githubUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2.5 bg-surface-900 dark:bg-surface-800 hover:bg-black text-white text-sm font-semibold rounded-xl transition-colors shadow-sm">
                    <GitBranch className="w-4 h-4" /> Clone Repository
                  </a>
                )}
                {project.demoUrl && (
                  <a href={project.demoUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#1a63ef] hover:bg-blue-600 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm">
                    <ExternalLink className="w-4 h-4" /> Launch Live Instance
                  </a>
                )}
              </div>

              {/* Prose-Portal Rich-Text HTML Body Processing Framework Layer Area */}
              <div className="mt-6 prose prose-portal dark:prose-invert max-w-none">
                <div dangerouslySetInnerHTML={{ __html: project.content || '<p className="text-surface-400 italic">No expanded abstract documentation submitted for this project matrix.</p>' }} />
              </div>
            </div>

            {/* Team Members Allocation Component Profile Matrix Block */}
            {project.teamMembers && project.teamMembers.length > 0 && (
              <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 p-6 rounded-2xl shadow-sm">
                <h3 className="text-sm font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 flex items-center gap-2 mb-4">
                  <Users className="w-4 h-4" /> Simulation & Co-Authorship Matrix
                </h3>
                <div className="flex flex-wrap gap-4">
                  {project.teamMembers.map((member: string) => (
                    <div key={member} className="flex items-center gap-2.5 px-3 py-1.5 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl">
                      <div className="w-6 h-6 bg-surface-200 rounded-full flex items-center justify-center font-bold text-[10px] text-surface-600 dark:text-surface-400">
                        {member.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-xs font-semibold text-surface-700 dark:text-surface-300">{member}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column Stack: Side Profile Cards & Adjacent Nodes */}
          <div className="space-y-6">
            
            {/* Author Attribution Card Core Module Component Card */}
            <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 p-6 rounded-2xl shadow-sm text-center">
              <h4 className="text-xs font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 mb-4 text-left">
                Principal Investigator
              </h4>
              <img
                src={project.author?.profile?.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${project.authorId}`}
                alt="Principal"
                className="w-16 h-16 rounded-full mx-auto bg-surface-50 p-1 border border-surface-200 dark:border-surface-800 shadow-inner"
              />
              <Link to={`/members/${project.authorId}`} className="block font-bold text-lg text-surface-900 dark:text-surface-50 mt-3 hover:text-[#1a63ef] transition-colors">
                {project.author?.profile?.fullName || 'Anonymous Engineer'}
              </Link>
              <p className="text-xs font-semibold text-[#1a63ef] uppercase tracking-wide mt-0.5">
                {project.author?.profile?.branch || 'Chemical Engineering'}
              </p>
              <p className="text-sm text-surface-500 dark:text-surface-400 mt-2">
                {project.author?.profile?.college || 'Core Academic Affiliate'}
              </p>
            </div>

            {/* Core Tech Stack Specification Chip Dashboard List Block */}
            <div className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 p-6 rounded-2xl shadow-sm">
              <h4 className="text-xs font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 flex items-center gap-1.5 mb-4">
                <Terminal className="w-3.5 h-3.5" /> Technical Dependencies
              </h4>
              <div className="flex flex-wrap gap-2">
                {project.techStack?.map((tech: string) => (
                  <span key={tech} className="px-3 py-1 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 text-surface-700 dark:text-surface-300 text-xs font-semibold rounded-lg">
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Related Research Artifact Cards Lateral Recommendations Loop Menu */}
            {relatedProjects.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-surface-400 dark:text-surface-500 px-1">
                  Parallel Research In Class
                </h4>
                {relatedProjects.map((rel: any) => (
                  <Link
                    key={rel.id}
                    to={`/projects/${rel.slug}`}
                    className="block bg-white dark:bg-surface-900 p-4 border border-surface-200 dark:border-surface-800 rounded-xl hover:border-surface-300 dark:hover:border-surface-700 transition-colors shadow-sm group"
                  >
                    <h5 className="font-bold text-sm text-surface-900 dark:text-surface-100 group-hover:text-[#1a63ef] line-clamp-1 transition-colors">
                      {rel.title}
                    </h5>
                    <p className="text-xs text-surface-400 dark:text-surface-500 mt-1 flex items-center gap-2">
                      <span>By {rel.author?.profile?.fullName || 'Academic Member'}</span>
                      <span>•</span>
                      <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" /> {rel.views}</span>
                    </p>
                  </Link>
                ))}
              </div>
            )}

          </div>

        </div>
      </div>
    </div>
  );
}