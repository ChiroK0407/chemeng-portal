import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useProjects } from '@/hooks/useProjects';
import { useDebounce } from '@/hooks/useDebounce';
// Use `useDebounce` for input debouncing (missing `useGithub` hook)
import { Search, Eye, GitBranch, ExternalLink, SlidersHorizontal } from 'lucide-react';

const PROJECT_CATEGORIES = [
  'Process Simulation',
  'Equipment Design',
  'Research Paper',
  'Optimization',
  'Data Science'
];

export default function ProjectListPage() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [techInput, setTechInput] = useState('');
  const [sortBy, setSortBy] = useState('createdAt');
  const [limit, setLimit] = useState(12);

  // Debounced input filters to optimize network requests
  const debouncedSearch = useDebounce(search, 300);
  const debouncedTech = useDebounce(techInput, 400);

  const { data, isLoading, isError } = useProjects({
    page: 1,
    limit,
    search: debouncedSearch,
    category: selectedCategory || undefined,
    techStack: debouncedTech || undefined,
    sortBy,
    sortDir: 'desc'
  });

  const getGradientFallback = (category: string) => {
    switch (category) {
      case 'Process Simulation': return 'from-blue-500 to-indigo-600';
      case 'Equipment Design': return 'from-teal-500 to-emerald-600';
      case 'Research Paper': return 'from-purple-500 to-pink-600';
      case 'Optimization': return 'from-orange-500 to-amber-600';
      default: return 'from-surface-400 to-surface-600';
    }
  };

  const projects = data?.data || [];
  const meta = data?.meta;
  const hasMore = meta ? meta.page < meta.totalPages : false;

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-950 pt-24 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Title Grid */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-surface-900 dark:text-surface-50">
              Project Showcase
            </h1>
            <p className="text-sm text-surface-500 dark:text-surface-400 mt-1">
              Explore simulation architectures, process blueprints, and advanced computational models.
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-xs font-medium text-surface-400 dark:text-surface-500 flex items-center gap-1.5">
              <SlidersHorizontal className="w-3.5 h-3.5" /> Sort By
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 text-sm font-medium rounded-xl text-surface-700 dark:text-surface-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-[#1a63ef]"
            >
              <option value="createdAt">Latest Uploads</option>
              <option value="views">Most Viewed</option>
            </select>
          </div>
        </div>

        {/* Horizontal Filtering Dashboard Control Panel */}
        <div className="bg-white dark:bg-surface-900 p-5 rounded-2xl border border-surface-200 dark:border-surface-800 shadow-sm mb-8 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
              <input
                type="text"
                placeholder="Search keywords, design parameters..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1a63ef] dark:text-surface-200"
              />
            </div>
            <input
              type="text"
              placeholder="Filter by technologies (e.g. Aspen, MATLAB, Python)..."
              value={techInput}
              onChange={(e) => setTechInput(e.target.value)}
              className="w-full px-4 py-2.5 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1a63ef] dark:text-surface-200"
            />
          </div>

          {/* Dynamic Chip Matrix Category Array Selector Loop */}
          <div className="flex flex-wrap gap-2 items-center pt-2 border-t border-surface-100 dark:border-surface-800">
            <span className="text-xs font-semibold uppercase tracking-wider text-surface-400 dark:text-surface-500 mr-2">
              Categories:
            </span>
            {PROJECT_CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(isSelected ? null : cat)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-full transition-all duration-200 ${
                    isSelected
                      ? 'bg-[#1a63ef] text-white shadow-sm'
                      : 'bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-surface-300 hover:bg-surface-200 dark:hover:bg-surface-700'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Card Grid Layout Matrix */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-80 bg-surface-200 dark:bg-surface-800 rounded-2xl" />
            ))}
          </div>
        ) : isError || projects.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-surface-900 border rounded-2xl border-surface-200 dark:border-surface-800">
            <p className="text-surface-500 dark:text-surface-400">No projects found matching the specified parameters.</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project: any) => (
                <div
                  key={project.id}
                  className="group bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 rounded-2xl shadow-sm overflow-hidden flex flex-col hover:shadow-md hover:border-surface-300 dark:hover:border-surface-700 transition-all duration-200"
                >
                  <Link to={`/projects/${project.slug}`} className="relative block h-48 w-full overflow-hidden">
                    {project.coverUrl ? (
                      <img
                        src={project.coverUrl}
                        alt={project.title}
                        className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className={`w-full h-full bg-gradient-to-br ${getGradientFallback(project.category)} flex items-center justify-center text-white/10 font-bold text-6xl select-none`}>
                        🧪
                      </div>
                    )}
                    <span className="absolute top-3 left-3 px-2.5 py-1 bg-black/40 backdrop-blur-md text-white rounded-md text-[11px] font-semibold tracking-wide uppercase">
                      {project.category}
                    </span>
                  </Link>

                  <div className="p-5 flex-1 flex flex-col">
                    <Link to={`/projects/${project.slug}`} className="block group-hover:text-[#1a63ef] transition-colors">
                      <h3 className="font-bold text-lg text-surface-900 dark:text-surface-100 line-clamp-1">
                        {project.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-surface-500 dark:text-surface-400 mt-2 line-clamp-2 flex-1">
                      {project.description || 'No supplementary abstract text initialized for this modeling pipeline.'}
                    </p>

                    <div className="flex flex-wrap gap-1.5 mt-4">
                      {project.techStack?.slice(0, 3).map((tech: string) => (
                        <span key={tech} className="px-2 py-0.5 bg-surface-50 dark:bg-surface-950 border border-surface-200 dark:border-surface-800 text-surface-600 dark:text-surface-300 text-xs font-medium rounded-md">
                          {tech}
                        </span>
                      ))}
                      {project.techStack?.length > 3 && (
                        <span className="px-2 py-0.5 bg-surface-100 dark:bg-surface-800 text-surface-500 text-xs font-semibold rounded-md">
                          +{project.techStack.length - 3} more
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between border-t border-surface-100 dark:border-surface-800 mt-5 pt-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={project.author?.profile?.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${project.authorId}`}
                          alt="Author"
                          className="w-7 h-7 rounded-full bg-surface-100"
                        />
                        <span className="text-sm font-semibold text-surface-700 dark:text-surface-300">
                          {project.author?.profile?.fullName || 'Anonymous Engineer'}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-surface-400 dark:text-surface-500">
                        <span className="text-xs font-medium flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5" /> {project.views}
                        </span>
                        {project.githubUrl && (
                          <a href={project.githubUrl} target="_blank" rel="noreferrer" className="hover:text-surface-700 dark:hover:text-surface-200">
                            <GitBranch className="w-4 h-4" />
                          </a>
                        )}
                        {project.demoUrl && (
                          <a href={project.demoUrl} target="_blank" rel="noreferrer" className="hover:text-[#1a63ef]">
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {hasMore && (
              <div className="flex justify-center mt-12">
                <button
                  onClick={() => setLimit((prev) => prev + 12)}
                  className="px-6 py-3 border border-surface-200 dark:border-surface-800 text-sm font-semibold rounded-xl bg-white dark:bg-surface-900 text-surface-700 dark:text-surface-200 shadow-sm hover:bg-surface-50 dark:hover:bg-surface-800 transition-colors"
                >
                  Load More Projects
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}