import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/axios';

export interface MemberFilters {
  page?: number;
  limit?: number;
  search?: string;
  role?: string; // 'student' | 'alumni' | 'faculty' | 'admin'
}

export function useMembers(filters: MemberFilters) {
  return useQuery({
    queryKey: ['members', filters],
    queryFn: async () => {
      const res = await api.get('/members', { params: filters });
      return res.data; // Expected format: { success: true, data: [...], meta: { total, page } }
    },
    placeholderData: (previousData) => previousData,
  });
}

export function useMember(id: string) {
  return useQuery({
    queryKey: ['member', id],
    queryFn: async () => {
      if (!id) throw new Error('Missing parameter thread id assignment.');
      const res = await api.get(`/members/${id}`);
      return res.data?.data || res.data; // Expected format: returns full user + profile + projects + blogs relation maps
    },
    enabled: !!id,
  });
}