import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/axios';

export interface OpportunityFilters {
  page?: number;
  limit?: number;
  type?: string; // 'internship' | 'full_time' | 'research' | 'fellowship' etc
  search?: string;
  isRemote?: boolean;
  location?: string;
  minStipend?: number;
  branch?: string;
  showOnlyOpen?: boolean;
  sortBy?: string;
}

export function useOpportunities(filters: OpportunityFilters) {
  return useQuery({
    queryKey: ['opportunities', filters],
    queryFn: async () => {
      const res = await api.get('/opportunities', { params: filters });
      return res.data; // Expected format: { success: true, data: [...], meta: { total, page, totalPages } }
    },
    placeholderData: (previousData) => previousData,
  });
}

export function useBookmarkOpportunity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (oppId: string) => {
      const res = await api.post(`/bookmarks/toggle`, { entityType: 'opportunity', entityId: oppId });
      return res.data;
    },
    onSuccess: () => {
      // Refresh the queries data arrays instantly to sync favorite toggle updates
      queryClient.invalidateQueries({ queryKey: ['opportunities'] });
    }
  });
}