import { useQuery } from '@tanstack/react-query';
import { projectService } from '@/services/project.service';

export interface ProjectFilters {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
  techStack?: string;
  sortBy?: string;
  sortDir?: string;
}

export function useProjects(filters: ProjectFilters) {
  return useQuery({
    queryKey: ['projects', filters],
    queryFn: async () => {
      const response = await projectService.getAll(filters);
      return response; // Passes { success: true, data: [...], meta: {...} }
    },
    placeholderData: (previousData) => previousData, // Keeps historical cache view alive while typing filters
  });
}

export function useProject(slug: string) {
  return useQuery({
    queryKey: ['project', slug],
    queryFn: async () => {
      if (!slug) throw new Error('Slug parsing constraint failed.');
      const response = await projectService.getBySlug(slug);
      return response.data;
    },
    enabled: !!slug,
  });
}