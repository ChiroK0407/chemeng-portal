import { Router } from 'express';
import * as MemberController from '../controllers/member.controller';
import { requireAuth } from '../middleware/auth.middleware';

const router = Router();

router.get('/', MemberController.getAll);
router.get('/:id', MemberController.getById);
router.put('/me', requireAuth, MemberController.updateProfile);

export default router;