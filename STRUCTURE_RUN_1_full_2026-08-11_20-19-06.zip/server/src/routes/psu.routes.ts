import { Router } from 'express';
import * as PsuController from '../controllers/psu.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { requireAdmin } from '../middleware/admin.middleware';

const router = Router();

// Middleware-free fallback checking to read authorization state non-destructively
const optionalAuth = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.split(' ')[1]) {
    return requireAuth(req, res, next);
  }
  next();
};

router.get('/', optionalAuth, PsuController.getAll);
router.get('/:slug', optionalAuth, PsuController.getBySlug);

// High-Privilege Administrative Portals
router.post('/', requireAuth, requireAdmin, PsuController.create);
router.put('/:slug', requireAuth, requireAdmin, PsuController.update);
router.delete('/:slug', requireAuth, requireAdmin, PsuController.remove);

export default router;