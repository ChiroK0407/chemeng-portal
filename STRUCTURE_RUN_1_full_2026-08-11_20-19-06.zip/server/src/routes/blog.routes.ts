import { Router } from 'express';
import * as BlogController from '../controllers/blog.controller';
import { requireAuth } from '../middleware/auth.middleware';

const router = Router();

const optionalAuth = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.split(' ')[1]) {
    return requireAuth(req, res, next);
  }
  next();
};

router.get('/', optionalAuth, BlogController.getAll);
router.get('/:slug', optionalAuth, BlogController.getBySlug);

// Secure Publication Handlers
router.post('/', requireAuth, BlogController.create);
router.put('/:slug', requireAuth, BlogController.update);
router.delete('/:slug', requireAuth, BlogController.remove);

export default router;