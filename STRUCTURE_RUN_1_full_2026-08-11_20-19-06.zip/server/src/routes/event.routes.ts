import { Router } from 'express';
import * as EventController from '../controllers/event.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { requireAdmin } from '../middleware/admin.middleware';

const router = Router();

router.get('/', EventController.getAll);
router.get('/:slug', EventController.getBySlug);

router.post('/', requireAuth, requireAdmin, EventController.create);
router.put('/:slug', requireAuth, requireAdmin, EventController.update);
router.delete('/:slug', requireAuth, requireAdmin, EventController.remove);

router.post('/:slug/rsvp', requireAuth, EventController.rsvp);
router.delete('/:slug/rsvp', requireAuth, EventController.cancelRsvp);

export default router;