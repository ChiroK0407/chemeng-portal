import { Router } from 'express';
import * as OpportunityController from '../controllers/opportunity.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { requireAdmin } from '../middleware/admin.middleware';

const router = Router();

const optionalAuth = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.split(' ')[1]) {
    return requireAuth(req, res, next);
  }
  next();
};

router.get('/', optionalAuth, OpportunityController.getAll);
router.get('/:id', OpportunityController.getById);

router.post('/', requireAuth, requireAdmin, OpportunityController.create);
router.put('/:id', requireAuth, requireAdmin, OpportunityController.update);
router.delete('/:id', requireAuth, requireAdmin, OpportunityController.remove);

router.post('/:id/bookmark', requireAuth, OpportunityController.bookmark);

export default router;