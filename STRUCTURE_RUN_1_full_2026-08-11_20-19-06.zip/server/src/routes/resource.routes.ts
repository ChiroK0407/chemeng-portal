import { Router } from 'express';
import * as ResourceController from '../controllers/resource.controller';
import { requireAuth } from '../middleware/auth.middleware';

const router = Router();

const optionalAuth = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.split(' ')[1]) {
    return requireAuth(req, res, next);
  }
  next();
};

router.get('/', optionalAuth, ResourceController.getAll);
router.get('/categories', ResourceController.getCategories);
router.get('/:id', ResourceController.getById);

router.post('/', requireAuth, ResourceController.create);
router.put('/:id', requireAuth, ResourceController.update);
router.delete('/:id', requireAuth, ResourceController.remove);

export default router;