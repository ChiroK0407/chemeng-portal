import { Router } from 'express';
import * as AuthController from '../controllers/auth.controller';
import { requireAuth } from '../middleware/auth.middleware';

const router = Router();

router.post('/register', AuthController.register);
router.post('/login', AuthController.login);
router.post('/forgot-password', AuthController.forgotPassword);
router.post('/reset-password', AuthController.resetPassword);
router.post('/refresh', AuthController.refreshTokens);
router.get('/verify-email/:token', AuthController.verifyEmail);

// Protected Endpoint Target Context
router.get('/me', requireAuth, AuthController.me);

export default router;