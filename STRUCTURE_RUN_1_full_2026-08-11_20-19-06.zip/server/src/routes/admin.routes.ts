import { Router } from 'express';
import * as AdminController from '../controllers/admin.controller';
import { requireAuth } from '../middleware/auth.middleware';
import { requireAdmin } from '../middleware/admin.middleware';

const router = Router();

// Apply administrative boundary guards globally across this routing path
router.use(requireAuth, requireAdmin);

router.get('/stats', AdminController.getStats);
router.get('/recent-activity', AdminController.getRecentActivity);
router.get('/charts', AdminController.getDashboardCharts);
router.get('/newsletter-subscribers', AdminController.getNewsletterSubscribers);

router.post('/manage-content', AdminController.manageContent);
router.post('/manage-users', AdminController.manageUsers);
router.post('/send-newsletter', AdminController.sendNewsletterEmail);
router.post('/moderate-comment', AdminController.moderateComment);

export default router;