import { Router } from 'express';
import * as ProjectController from '../controllers/project.controller';
import { requireAuth } from '../middleware/auth.middleware';

const router = Router();

const optionalAuth = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.split(' ')[1]) {
    return requireAuth(req, res, next);
  }
  next();
};

router.get('/', optionalAuth, ProjectController.getAll);
router.get('/:slug', optionalAuth, ProjectController.getBySlug);

// Mutative Action Hooks
router.post('/', requireAuth, ProjectController.create);
router.put('/:slug', requireAuth, ProjectController.update);
router.delete('/:slug', requireAuth, ProjectController.remove);

export default router;