import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';

import authRoutes from './routes/auth.routes';
import psuRoutes from './routes/psu.routes';
import projectRoutes from './routes/project.routes';
import blogRoutes from './routes/blog.routes';
import eventRoutes from './routes/event.routes';
import opportunityRoutes from './routes/opportunity.routes';
import resourceRoutes from './routes/resource.routes';
import memberRoutes from './routes/member.routes';

import { errorHandler } from './middleware/error.middleware';

// Load environmental parameters from workspace disk variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// ── 1. GLOBAL SECURITY & RESOURCE SHARING ──
app.use(helmet());
app.use(
  cors({
    origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : 'http://localhost:5173',
    credentials: true,
  })
);
app.use(express.json());

// ── 2. BRUTE-FORCE RATE LIMITING INTERCEPTOR ──
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15-minute timeframe window
  max: 100, // Caps each IP connection channel to 100 cycles
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many requests originating from this IP channel. Please retry in 15 minutes.',
    code: 'TOO_MANY_REQUESTS',
  },
});
app.use('/api/', apiLimiter);

// ── 3. ROUTE COMPONENT STUBS MAPPING ──
// Empty fallback router shells to map the required prefixes cleanly
const stubRouter = () => {
  const router = express.Router();
  router.all('*', (req, res) => {
    res.status(501).json({ success: false, message: 'Endpoint pipeline implementation coming soon.' });
  });
  return router;
};

app.use('/api/auth', authRoutes);
app.use('/api/psus', psuRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/blogs', blogRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/opportunities', opportunityRoutes);
app.use('/api/resources', resourceRoutes);
app.use('/api/members', memberRoutes);

// ── 4. EXPLICIT 404 ROUTE HANDLER ──
app.use('*', (req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Cannot analyze or route the structural endpoint path: ${req.originalUrl}`,
    code: 'ROUTE_NOT_FOUND',
  });
});

// ── 5. CENTRALIZED GLOBAL ERROR FALLBACK ──
app.use(errorHandler);

// ── 6. THREAD SYSTEM EXECUTION BOOTSTRAP ──
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});