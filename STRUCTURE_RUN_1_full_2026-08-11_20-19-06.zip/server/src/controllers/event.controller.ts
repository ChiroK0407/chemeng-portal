import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const search = (req.query.search as string) || '';
    const sortBy = (req.query.sortBy as string) || 'startsAt';
    const sortDir = (req.query.sortDir as string) || 'asc';

    const status = req.query.status as string;
    const isOnline = req.query.isOnline === 'true' ? true : req.query.isOnline === 'false' ? false : undefined;
    const upcomingOnly = req.query.upcomingOnly === 'true';

    const whereClause: any = {
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
          { venue: { contains: search, mode: 'insensitive' } }
        ]
      }),
      ...(status && { status: status as any }),
      ...(isOnline !== undefined && { isOnline }),
      ...(upcomingOnly && { startsAt: { gte: new Date() } })
    };

    const [events, total] = await Promise.all([
      prisma.event.findMany({
        where: whereClause,
        orderBy: { [sortBy]: sortDir },
        skip,
        take: limit
      }),
      prisma.event.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: events,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getBySlug = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const event = await prisma.event.findUnique({
      where: { slug },
      include: { organizer: true }
    });

    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    res.status(200).json({ success: true, data: event });
  } catch (error) { next(error); }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const newEvent = await prisma.event.create({
      data: {
        ...req.body,
        organizerId: req.user!.id
      }
    });
    res.status(201).json({ success: true, data: newEvent });
  } catch (error) { next(error); }
};

export const update = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const updatedEvent = await prisma.event.update({
      where: { slug },
      data: req.body
    });
    res.status(200).json({ success: true, data: updatedEvent });
  } catch (error) { next(error); }
};

export const remove = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    await prisma.event.delete({ where: { slug } });
    res.status(200).json({ success: true, data: null, message: 'Event deployment record completely dropped.' });
  } catch (error) { next(error); }
};

export const rsvp = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const userId = req.user!.id;

    const event = await prisma.event.findUnique({ where: { slug } });
    if (!event) return res.status(404).json({ success: false, message: 'Target event missing.' });

    // Validate capacity bounds safely
    if (event.maxCapacity && event.rsvpCount >= event.maxCapacity) {
      return res.status(400).json({ success: false, message: 'Event has reached maximum target capacity limits.' });
    }

    // Check for duplicate RSVP constraints in the joint map space
    const existingRsvp = await prisma.eventRSVP.findUnique({
      where: { userId_eventId: { userId, eventId: event.id } }
    });
    if (existingRsvp) return res.status(400).json({ success: false, message: 'User already has an active registration slot.' });

    // Batch operational verification together inside a transactional loop
    await prisma.$transaction([
      prisma.eventRSVP.create({ data: { userId, eventId: event.id } }),
      prisma.event.update({
        where: { id: event.id },
        data: { rsvpCount: { increment: 1 } }
      })
    ]);

    res.status(200).json({ success: true, message: 'RSVP confirmed successfully.' });
  } catch (error) { next(error); }
};

export const cancelRsvp = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const userId = req.user!.id;

    const event = await prisma.event.findUnique({ where: { slug } });
    if (!event) return res.status(404).json({ success: false, message: 'Target event missing.' });

    const existingRsvp = await prisma.eventRSVP.findUnique({
      where: { userId_eventId: { userId, eventId: event.id } }
    });
    if (!existingRsvp) return res.status(400).json({ success: false, message: 'No active RSVP registry found.' });

    await prisma.$transaction([
      prisma.eventRSVP.delete({ where: { userId_eventId: { userId, eventId: event.id } } }),
      prisma.event.update({
        where: { id: event.id },
        data: { rsvpCount: { decrement: 1 } }
      })
    ]);

    res.status(200).json({ success: true, message: 'RSVP cancelled successfully.' });
  } catch (error) { next(error); }
};