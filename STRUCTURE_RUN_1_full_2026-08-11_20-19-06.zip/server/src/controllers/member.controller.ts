import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const search = (req.query.search as string) || '';
    const role = req.query.role as string;
    const branch = req.query.branch as string;
    const skills = req.query.skills as string; // Comma-separated array sequence

    const whereClause: any = {
      user: { isDeleted: false }, // Filter out soft-deleted users
      ...(search && { fullName: { contains: search, mode: 'insensitive' } }),
      ...(branch && { branch }),
      ...(role && { user: { role: role as any } }),
      ...(skills && { skills: { hasEvery: skills.split(',') } })
    };

    const [profiles, total] = await Promise.all([
      prisma.profile.findMany({
        where: whereClause,
        include: { user: { select: { role: true, email: true } } },
        skip,
        take: limit
      }),
      prisma.profile.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: profiles,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;

    // Retrieve full profile alongside filtered published authorship parameters
    const profile = await prisma.profile.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            role: true,
            projects: { where: { status: 'published' } },
            blogs: { where: { status: 'published' } }
          }
        }
      }
    });

    if (!profile) return res.status(404).json({ success: false, message: 'Member profile thread index missing.' });

    res.status(200).json({ success: true, data: profile });
  } catch (error) { next(error); }
};

export const updateProfile = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = req.user!.id; // Enforced profile mapping isolation anchor

    const updatedProfile = await prisma.profile.update({
      where: { userId },
      data: req.body
    });

    res.status(200).json({ success: true, data: updatedProfile, message: 'Engineering portfolio card synchronized successfully.' });
  } catch (error) { next(error); }
};