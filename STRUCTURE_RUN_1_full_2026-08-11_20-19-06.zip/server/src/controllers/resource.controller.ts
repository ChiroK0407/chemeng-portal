import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const search = (req.query.search as string) || '';
    const type = req.query.type as string;
    const subject = req.query.subject as string;
    const semester = parseInt(req.query.semester as string);
    const categoryId = req.query.categoryId as string; // Read categorical inputs

    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    const whereClause: any = {
      ...(search && { title: { contains: search, mode: 'insensitive' } }),
      ...(!isAdminMode && { status: 'published' }),
      ...(type && { type }),
      ...(subject && { subject: { contains: subject, mode: 'insensitive' } }),
      ...(semester && { semester }),
      ...(categoryId && { categoryId })
    };

    const [resources, total] = await Promise.all([
      prisma.resource.findMany({
        where: whereClause,
        // ✅ FIXED: Included categorical entity definitions and uploader profiles
        include: {
          category: true,
          uploadedBy: { select: { profile: true } }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.resource.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: resources,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    const resource = await prisma.resource.update({
      where: { id },
      data: { downloads: { increment: 1 } },
      include: { category: true, uploadedBy: { select: { profile: true } } }
    });

    res.status(200).json({ success: true, data: resource });
  } catch (error) { next(error); }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const newResource = await prisma.resource.create({
      data: {
        ...req.body,
        uploadedById: req.user!.id
      }
    });
    res.status(201).json({ success: true, data: newResource });
  } catch (error) { next(error); }
};

export const update = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const resource = await prisma.resource.findUnique({ where: { id } });

    if (!resource) return res.status(404).json({ success: false, message: 'Resource link broken.' });

    const isUploader = resource.uploadedById === req.user!.id;
    const isAdmin = req.user!.role.toUpperCase() === 'ADMIN';

    if (!isUploader && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden. High privilege mapping verification crashed.' });
    }

    const updated = await prisma.resource.update({ where: { id }, data: req.body });
    res.status(200).json({ success: true, data: updated });
  } catch (error) { next(error); }
};

export const remove = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const resource = await prisma.resource.findUnique({ where: { id } });

    if (!resource) return res.status(404).json({ success: false, message: 'Resource not found.' });

    const isUploader = resource.uploadedById === req.user!.id;
    const isAdmin = req.user!.role.toUpperCase() === 'ADMIN';

    if (!isUploader && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden access scope context violation.' });
    }

    await prisma.resource.delete({ where: { id } });
    res.status(200).json({ success: true, message: 'Resource document cleanly dropped.' });
  } catch (error) { next(error); }
};

export const getCategories = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Fallback schema matching logic to check for unified categories vs resource-specific models
    const targetModel = (prisma as any).resourceCategory || (prisma as any).category;
    const categories = await targetModel.findMany({
      where: { entityType: 'resource' },
      select: { id: true, name: true, slug: true },
      orderBy: { name: 'asc' }
    });

    res.status(200).json({ success: true, data: categories });
  } catch (error) { next(error); }
};