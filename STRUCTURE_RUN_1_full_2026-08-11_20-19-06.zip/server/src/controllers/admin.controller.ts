import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY || 're_mock_key');

export const getStats = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const [users, psus, projects, blogs, events, opportunities, resources, newsletters] = await Promise.all([
      prisma.user.count({ where: { isDeleted: false } }),
      prisma.psu.count(),
      prisma.project.count(),
      prisma.blog.count(),
      prisma.event.count(),
      prisma.opportunity.count(),
      prisma.resource.count(),
      prisma.newsletter.count()
    ]);

    res.status(200).json({
      success: true,
      data: { users, psus, projects, blogs, events, opportunities, resources, newsletters }
    });
  } catch (error) { next(error); }
};

export const getRecentActivity = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const [users, projects, blogs] = await Promise.all([
      prisma.user.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        select: { id: true, email: true, role: true, createdAt: true, profile: true }
      }),
      prisma.project.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { author: { select: { profile: true } } }
      }),
      prisma.blog.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { author: { select: { profile: true } } }
      })
    ]);

    res.status(200).json({ success: true, data: { users, projects, blogs } });
  } catch (error) { next(error); }
};

export const manageContent = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { contentType, action, ids } = req.body; 
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ success: false, message: 'No target entity identifiers provided.' });
    }

    const client: any = (prisma as any)[contentType];
    if (!client) return res.status(400).json({ success: false, message: 'Invalid entity collection specified.' });

    if (action === 'delete') {
      await client.deleteMany({ where: { id: { in: ids } } });
    } else {
      const statusMap = { publish: 'published', archive: 'archived' };
      const status = (statusMap as any)[action];
      
      await client.updateMany({
        where: { id: { in: ids } },
        data: {
          status,
          ...(status === 'published' && contentType === 'blog' && { publishedAt: new Date() })
        }
      });
    }

    res.status(200).json({ success: true, message: `Bulk content operation executed successfully for action: ${action}` });
  } catch (error) { next(error); }
};

export const manageUsers = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { targetUserId, action, role } = req.body; 

    if (action === 'updateRole') {
      if (!role) return res.status(400).json({ success: false, message: 'Missing target role initialization payload.' });
      const updated = await prisma.user.update({
        where: { id: targetUserId },
        data: { role: role as any }
      });
      return res.status(200).json({ success: true, data: updated });
    }

    if (action === 'deactivate') {
      const deactivated = await prisma.user.update({
        where: { id: targetUserId },
        data: { isDeleted: true, deletedAt: new Date() }
      });
      return res.status(200).json({ success: true, data: deactivated, message: 'User channel deactivated.' });
    }

    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where: { isDeleted: false },
        include: { profile: true },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      prisma.user.count({ where: { isDeleted: false } })
    ]);

    res.status(200).json({
      success: true,
      data: users,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getNewsletterSubscribers = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const skip = (page - 1) * limit;

    const [subscribers, total] = await Promise.all([
      prisma.newsletter.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      prisma.newsletter.count()
    ]);

    res.status(200).json({
      success: true,
      data: subscribers,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const sendNewsletterEmail = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { subject, html, audienceFilter } = req.body; 

    const filterClause = audienceFilter === 'verified' ? { user: { isEmailVerified: true } } : {};
    const subs = await prisma.newsletter.findMany({ where: filterClause, select: { email: true } });

    if (subs.length === 0) {
      return res.status(200).json({ success: true, message: 'No active recipients found for filter.' });
    }

    // Fixed error 7006: Added explicit type annotation (sub: { email: string })
    const emailBatch = subs.map((sub: { email: string }) => ({
      from: process.env.EMAIL_FROM || 'ChemEng Portal <newsletter@chemengportal.com>',
      to: sub.email,
      subject: subject,
      html: html
    }));

    if (process.env.RESEND_API_KEY) {
      // Fixed error 2551: Changed .batches.create() to native correct .batch.send() method
      await resend.batch.send(emailBatch);
    } else {
      console.log(`[MOCK NEWSLETTER BATCH] Transmission size: ${emailBatch.length} items.`);
    }

    res.status(200).json({ success: true, message: `Newsletter successfully sent to ${subs.length} users.` });
  } catch (error) { next(error); }
};

export const moderateComment = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { commentId, action } = req.body; 

    if (action === 'delete') {
      await prisma.comment.update({
        where: { id: commentId },
        data: { isDeleted: true }
      });
      return res.status(200).json({ success: true, message: 'Comment soft-deleted by moderator.' });
    }

    if (action === 'approve') {
      return res.status(200).json({ success: true, message: 'Comment approved.' });
    }

    res.status(400).json({ success: false, message: 'Invalid moderation operation requested.' });
  } catch (error) { next(error); }
};

export const getDashboardCharts = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const userRegistrations = await prisma.$queryRaw`
      SELECT TO_CHAR(created_at, 'YYYY-MM') as month, COUNT(*)::int as count 
      FROM users 
      WHERE created_at >= ${sixMonthsAgo} AND is_deleted = false
      GROUP BY month ORDER BY month ASC
    `;

    const blogPublications = await prisma.$queryRaw`
      SELECT TO_CHAR(published_at, 'YYYY-MM') as month, COUNT(*)::int as count 
      FROM blogs 
      WHERE published_at >= ${sixMonthsAgo} AND status = 'published'
      GROUP BY month ORDER BY month ASC
    `;

    const topPsus = await prisma.bookmark.groupBy({
      by: ['entityId'],
      where: { entityType: 'psu' },
      _count: { entityId: true },
      orderBy: { _count: { entityId: 'desc' } },
      take: 5
    });

    // Fixed error 7006: Added structural type inline (item: { entityId: string; _count: { entityId: number } })
    // Fixed Casing Check: Shifted prisma.pSU to lowercase schema matching prisma.psu
    const topPsusHydrated = await Promise.all(
      topPsus.map(async (item: { entityId: string }) => {
        const psuRecord = await prisma.psu.findUnique({ where: { id: item.entityId }, select: { name: true } });
        return { name: psuRecord?.name || 'Unknown PSU', bookmarks: 1 };
      })
    );

    const opportunitiesByType = await prisma.opportunity.groupBy({
      by: ['type'],
      _count: { type: true }
    });

    // Fixed error 7006: Added explicit mapping type (item: { type: string; _count: { type: number } })
    const formattedOppTypes = opportunitiesByType.map((item: { type: string; _count: { type: number } }) => ({
      type: item.type,
      count: item._count.type
    }));

    res.status(200).json({
      success: true,
      data: {
        newUsersPerMonth: userRegistrations,
        contentPublishedPerMonth: blogPublications,
        topPsus: topPsusHydrated,
        opportunitiesByType: formattedOppTypes
      }
    });
  } catch (error) { next(error); }
};