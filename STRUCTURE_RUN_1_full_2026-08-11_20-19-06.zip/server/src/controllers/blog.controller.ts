import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const search = (req.query.search as string) || '';
    const sortBy = (req.query.sortBy as string) || 'createdAt';
    const sortDir = (req.query.sortDir as string) || 'desc';

    const categoryId = req.query.categoryId as string;
    const tag = req.query.tag as string;

    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    const whereClause: any = {
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          { content: { contains: search, mode: 'insensitive' } }
        ]
      }),
      ...(!isAdminMode && { status: 'published' }),
      ...(categoryId && { categoryId }),
      // Adjusting safely for schema setup models mapping tags arrays
      ...(tag && { tags: { has: tag } })
    };

    const [blogs, total] = await Promise.all([
      prisma.blog.findMany({
        where: whereClause,
        include: {
          author: { select: { profile: true } }
        },
        orderBy: { [sortBy]: sortDir },
        skip,
        take: limit
      }),
      prisma.blog.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: blogs,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getBySlug = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    const blog = await prisma.blog.update({
      where: { slug },
      data: { views: { increment: 1 } },
      include: {
        author: { select: { profile: true } }
      }
    });

    if (!blog || (!isAdminMode && blog.status !== 'published')) {
      return res.status(404).json({ success: false, message: 'Research publication missing.' });
    }

    res.status(200).json({ success: true, data: blog });
  } catch (error) { next(error); }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { content, status, ...rest } = req.body;
    
    // Automated Reading Lifespan Calculation Loop Metric (~200 Words/Min standard)
    const wordCount = content ? content.split(/\s+/).length : 0;
    const readTimeMin = Math.max(1, Math.ceil(wordCount / 200));

    const isPublished = status === 'published';

    const newBlog = await prisma.blog.create({
      data: {
        ...rest,
        content,
        status: status || 'draft',
        readTimeMin,
        authorId: req.user!.id,
        publishedAt: isPublished ? new Date() : null
      }
    });

    res.status(201).json({ success: true, data: newBlog });
  } catch (error) { next(error); }
};

export const update = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const blog = await prisma.blog.findUnique({ where: { slug } });

    if (!blog) return res.status(404).json({ success: false, message: 'Target blog record missing.' });

    const isOwner = blog.authorId === req.user?.id;
    const isAdmin = req.user?.role?.toUpperCase() === 'ADMIN';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden. Modification rights missing.' });
    }

    const updates: any = { ...req.body };

    // Handle automated reading metrics calculation if text updates
    if (req.body.content) {
      const wordCount = req.body.content.split(/\s+/).length;
      updates.readTimeMin = Math.max(1, Math.ceil(wordCount / 200));
    }

    // Capture lifecycle context transitions for published statuses
    if (req.body.status === 'published' && blog.status !== 'published') {
      updates.publishedAt = new Date();
    }

    const updatedBlog = await prisma.blog.update({
      where: { slug },
      data: updates
    });

    res.status(200).json({ success: true, data: updatedBlog });
  } catch (error) { next(error); }
};

export const remove = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const blog = await prisma.blog.findUnique({ where: { slug } });

    if (!blog) return res.status(404).json({ success: false, message: 'Target article not found.' });

    const isOwner = blog.authorId === req.user?.id;
    const isAdmin = req.user?.role?.toUpperCase() === 'ADMIN';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden. Purge command rejected.' });
    }

    await prisma.blog.delete({ where: { slug } });
    res.status(200).json({ success: true, data: null, message: 'Publication cleared.' });
  } catch (error) { next(error); }
};