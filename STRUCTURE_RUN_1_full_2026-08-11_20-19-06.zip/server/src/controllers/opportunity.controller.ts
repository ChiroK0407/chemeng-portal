import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const search = (req.query.search as string) || '';
    const type = req.query.type as string;
    const isRemote = req.query.isRemote === 'true' ? true : req.query.isRemote === 'false' ? false : undefined;
    const location = req.query.location as string;
    const minStipend = parseFloat(req.query.minStipend as string);

    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    // ✅ FIXED: Map frontend semantic sorting values to actual database columns
    const frontendSortBy = (req.query.sortBy as string) || 'latest';
    let sortBy = 'createdAt';
    let sortDir = 'desc';

    if (frontendSortBy === 'deadline') {
      sortBy = 'deadline';
      sortDir = 'asc';
    } else if (frontendSortBy === 'stipend_desc') {
      sortBy = 'stipendMax';
      sortDir = 'desc';
    }

    const whereClause: any = {
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          { company: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } }
        ]
      }),
      ...(!isAdminMode && { status: 'published' }),
      ...(type && { type: type as any }),
      ...(isRemote !== undefined && { isRemote }),
      ...(location && { location: { contains: location, mode: 'insensitive' } }),
      ...(minStipend && { stipendMax: { gte: minStipend } })
    };

    const [opportunities, total] = await Promise.all([
      prisma.opportunity.findMany({
        where: whereClause,
        orderBy: { [sortBy]: sortDir }, // Safe, validated column names passed to Prisma
        skip,
        take: limit
      }),
      prisma.opportunity.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: opportunities,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const opportunity = await prisma.opportunity.findUnique({ where: { id } });

    if (!opportunity) return res.status(404).json({ success: false, message: 'Career target index missing.' });

    res.status(200).json({ success: true, data: opportunity });
  } catch (error) { next(error); }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const newOpp = await prisma.opportunity.create({
      data: {
        ...req.body,
        postedById: req.user!.id
      }
    });
    res.status(201).json({ success: true, data: newOpp });
  } catch (error) { next(error); }
};

export const update = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const updated = await prisma.opportunity.update({
      where: { id },
      data: req.body
    });
    res.status(200).json({ success: true, data: updated });
  } catch (error) { next(error); }
};

export const remove = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    await prisma.opportunity.delete({ where: { id } });
    res.status(200).json({ success: true, data: null, message: 'Opportunity profile dropped.' });
  } catch (error) { next(error); }
};

export const bookmark = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;

    const existingBookmark = await prisma.bookmark.findUnique({
      where: {
        userId_entityType_entityId: {
          userId,
          entityType: 'opportunity',
          entityId: id
        }
      }
    });

    if (existingBookmark) {
      await prisma.bookmark.delete({ where: { id: existingBookmark.id } });
      return res.status(200).json({ success: true, data: { bookmarked: false }, message: 'Bookmark removed.' });
    } else {
      await prisma.bookmark.create({
        data: {
          userId,
          entityType: 'opportunity',
          entityId: id
        }
      });
      return res.status(200).json({ success: true, data: { bookmarked: true }, message: 'Bookmark added.' });
    }
  } catch (error) { next(error); }
};