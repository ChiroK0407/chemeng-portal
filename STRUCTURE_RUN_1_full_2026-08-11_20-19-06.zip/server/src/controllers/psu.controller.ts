import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;
    
    const search = (req.query.search as string) || '';
    const sortBy = (req.query.sortBy as string) || 'createdAt';
    const sortDir = (req.query.sortDir as string) || 'desc';

    // Filtration Parameters
    const sector = req.query.sector as string;
    const gateRequired = req.query.gateRequired === 'true' ? true : req.query.gateRequired === 'false' ? false : undefined;
    const minPackage = parseFloat(req.query.minPackage as string);
    const maxPackage = parseFloat(req.query.maxPackage as string);
    const branch = req.query.branch as string;

    // Role-based Content Insulation Boundary
    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    const whereClause: any = {
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' } },
          { fullName: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } }
        ]
      }),
      ...(!isAdminMode && { status: 'published' }),
      ...(sector && { sector }),
      ...(gateRequired !== undefined && { gateRequired }),
      ...(branch && { eligibleBranches: { has: branch } }),
      ...((minPackage || maxPackage) && {
        packageMaxLpa: {
          ...(minPackage && { gte: minPackage }),
          ...(maxPackage && { lte: maxPackage })
        }
      })
    };

    const [psus, total] = await Promise.all([
      prisma.psu.findMany({
        where: whereClause,
        orderBy: { [sortBy]: sortDir },
        skip,
        take: limit
      }),
      prisma.psu.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: psus,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getBySlug = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    const psu = await prisma.psu.findUnique({ where: { slug } });
    if (!psu || (!isAdminMode && psu.status !== 'published')) {
      return res.status(404).json({ success: false, message: 'PSU profile not found.' });
    }

    res.status(200).json({ success: true, data: psu });
  } catch (error) { next(error); }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const newPsu = await prisma.psu.create({ data: req.body });
    res.status(201).json({ success: true, data: newPsu, message: 'PSU resource created successfully.' });
  } catch (error) { next(error); }
};

export const update = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const updatedPsu = await prisma.psu.update({
      where: { slug },
      data: req.body
    });
    res.status(200).json({ success: true, data: updatedPsu, message: 'PSU resource updated successfully.' });
  } catch (error) { next(error); }
};

export const remove = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    await prisma.psu.delete({ where: { slug } });
    res.status(200).json({ success: true, data: null, message: 'PSU profile purged from system registers.' });
  } catch (error) { next(error); }
};