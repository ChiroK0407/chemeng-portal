import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { AuthService } from '../services/auth.service';

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(2)
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string()
});

const forgotPasswordSchema = z.object({
  email: z.string().email()
});

const resetPasswordSchema = z.object({
  token: z.string(),
  password: z.string().min(8)
});

const refreshTokensSchema = z.object({
  refreshToken: z.string()
});

export const register = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = registerSchema.parse(req.body);
    const result = await AuthService.register(data.email, data.password, data.fullName);
    res.status(201).json({ success: true, data: result, message: 'User registered successfully.' });
  } catch (error) { next(error); }
};

export const login = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide both email and password parameters.' });
    }

    const result = await AuthService.login(email, password);
    
    return res.status(200).json({
      success: true,
      data: result
    });
  } catch (error: any) {
    // 💡 Catch the credential matching errors explicitly and return a clean 401 status code
    return res.status(401).json({
      success: false,
      message: error.message || 'Authentication failed. Please verify your entries.'
    });
  }
};

export const forgotPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = forgotPasswordSchema.parse(req.body);
    await AuthService.forgotPassword(data.email);
    res.status(200).json({ success: true, data: null, message: 'If registered, a security reset email has been sent.' });
  } catch (error) { next(error); }
};

export const resetPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = resetPasswordSchema.parse(req.body);
    await AuthService.resetPassword(data.token, data.password);
    res.status(200).json({ success: true, data: null, message: 'Password has been reset successfully.' });
  } catch (error) { next(error); }
};

export const refreshTokens = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = refreshTokensSchema.parse(req.body);
    const result = await AuthService.refreshTokens(data.refreshToken);
    res.status(200).json({ success: true, data: result, message: 'Tokens refreshed successfully.' });
  } catch (error) { next(error); }
};

export const verifyEmail = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = z.string().parse(req.params.token);
    await AuthService.verifyEmail(token);
    res.status(200).json({ success: true, data: null, message: 'Email confirmed successfully.' });
  } catch (error) { next(error); }
};

export const me = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = req.user?.id;
    if (!userId) throw new Error('Context resolution error.');
    const result = await AuthService.me(userId);
    res.status(200).json({ success: true, data: result, message: 'Current profile retrieved.' });
  } catch (error) { next(error); }
};