import { Request, Response, NextFunction } from 'express';
import { prisma } from '../lib/prisma';

export const getAll = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 12;
    const skip = (page - 1) * limit;

    const search = (req.query.search as string) || '';
    const sortBy = (req.query.sortBy as string) || 'createdAt';
    const sortDir = (req.query.sortDir as string) || 'desc';

    const category = req.query.category as string;
    const techStack = req.query.techStack as string; // Expecting comma-separated strings

    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    const whereClause: any = {
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } }
        ]
      }),
      ...(!isAdminMode && { status: 'published' }),
      ...(category && { category }),
      ...(techStack && { techStack: { hasEvery: techStack.split(',') } })
    };

    const [projects, total] = await Promise.all([
      prisma.project.findMany({
        where: whereClause,
        include: { author: { select: { profile: true } } },
        orderBy: { [sortBy]: sortDir },
        skip,
        take: limit
      }),
      prisma.project.count({ where: whereClause })
    ]);

    res.status(200).json({
      success: true,
      data: projects,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) { next(error); }
};

export const getBySlug = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const isAdminMode = req.user?.role?.toUpperCase() === 'ADMIN';

    // Fetch and atomically increment the analytics count loop view counter
    const project = await prisma.project.update({
      where: { slug },
      data: { views: { increment: 1 } },
      include: { author: { select: { profile: true } } }
    });

    if (!project || (!isAdminMode && project.status !== 'published')) {
      return res.status(404).json({ success: false, message: 'Simulation project record unavailable.' });
    }

    res.status(200).json({ success: true, data: project });
  } catch (error) { next(error); }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user?.id) return res.status(401).json({ success: false, message: 'Missing session anchor.' });

    const newProject = await prisma.project.create({
      data: {
        ...req.body,
        authorId: req.user.id // Enforcing runtime authentication identity
      }
    });

    res.status(201).json({ success: true, data: newProject, message: 'Project registry success.' });
  } catch (error) { next(error); }
};

export const update = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const project = await prisma.project.findUnique({ where: { slug } });

    if (!project) return res.status(404).json({ success: false, message: 'Target project missing.' });

    // Authorization Verification Boundary
    const isOwner = project.authorId === req.user?.id;
    const isAdmin = req.user?.role?.toUpperCase() === 'ADMIN';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden. Modification rights missing.' });
    }

    const updatedProject = await prisma.project.update({
      where: { slug },
      data: req.body
    });

    res.status(200).json({ success: true, data: updatedProject });
  } catch (error) { next(error); }
};

export const remove = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const project = await prisma.project.findUnique({ where: { slug } });

    if (!project) return res.status(404).json({ success: false, message: 'Target resource not found.' });

    const isOwner = project.authorId === req.user?.id;
    const isAdmin = req.user?.role?.toUpperCase() === 'ADMIN';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden. Purge sequence verification failed.' });
    }

    await prisma.project.delete({ where: { slug } });
    res.status(200).json({ success: true, data: null, message: 'Project document cleared.' });
  } catch (error) { next(error); }
};