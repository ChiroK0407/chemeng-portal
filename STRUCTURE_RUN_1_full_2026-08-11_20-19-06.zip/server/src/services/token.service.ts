import jwt from 'jsonwebtoken';
import crypto from 'crypto';

export class TokenService {
  private static getAccessSecret(): string {
    return process.env.JWT_SECRET || 'default_access_secret_key_change_me';
  }

  private static getRefreshSecret(): string {
    return process.env.JWT_REFRESH_SECRET || 'default_refresh_secret_key_change_me';
  }

  static generateAccessToken(userId: string, role: string): string {
    return jwt.sign(
      { id: userId, role },
      this.getAccessSecret(),
      { expiresIn: (process.env.JWT_EXPIRES_IN || '15m') as any }
    );
  }

  static generateRefreshToken(userId: string): string {
    return jwt.sign(
      { id: userId },
      this.getRefreshSecret(),
      { expiresIn: (process.env.JWT_REFRESH_EXPIRES_IN || '7d') as any }
    );
  }

  static verifyAccessToken(token: string): any {
    return jwt.verify(token, this.getAccessSecret());
  }

  static verifyRefreshToken(token: string): any {
    return jwt.verify(token, this.getRefreshSecret());
  }

  static generateResetToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }
}