import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { Resend } from 'resend';
import { Prisma } from '@prisma/client';
import prisma from '../lib/prisma';
import { TokenService } from './token.service';

const resend = new Resend(process.env.RESEND_API_KEY || 're_mock_key');

export class AuthService {
  private static hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  static async register(email: string, passwordString: string, fullName: string) {
    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) throw new Error('A user with this email address already exists.');

    const hashedPassword = await bcrypt.hash(passwordString, 12);
    
    // Generate a secure verification token on register
    const verificationToken = TokenService.generateResetToken();

    const user = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      const newUser = await tx.user.create({
        data: {
          email,
          password: hashedPassword,
          role: 'student',
          isEmailVerified: false,
          verificationToken: verificationToken // Store it securely
        }
      });

      await tx.profile.create({
        data: {
          userId: newUser.id,
          fullName,
          username: email.split('@')[0] + Math.floor(1000 + Math.random() * 9000)
        }
      });

      return newUser;
    });

    const verifyUrl = `${process.env.APP_URL || 'http://localhost:5173'}/auth/callback?token=${verificationToken}`;

    try {
      await resend.emails.send({
        from: process.env.EMAIL_FROM || 'ChemEng Portal <noreply@chemengportal.com>',
        to: email,
        subject: 'Welcome to ChemEng Portal!',
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #495057;">
            <h2 style="color: #1a63ef;">🧪 Welcome, ${fullName}!</h2>
            <p>Your account has been successfully engineered. Please verify your email channel using the button below:</p>
            <p><a href="${verifyUrl}" style="display: inline-block; background-color: #1a63ef; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold;">Verify Email Address</a></p>
          </div>
        `
      });
    } catch (err) {
      console.warn('Email delivery skipped: Verify your RESEND_API_KEY setup.', err);
    }

    const accessToken = TokenService.generateAccessToken(user.id, user.role);
    const refreshToken = TokenService.generateRefreshToken(user.id);

    return { accessToken, refreshToken, user: { id: user.id, email: user.email, role: user.role } };
  }

  static async login(email: string, passwordString: string) {
    const user = await prisma.user.findUnique({ where: { email }, include: { profile: true } });
    if (!user || user.isDeleted) throw new Error('Invalid email or password combination.');

    const isMatch = await bcrypt.compare(passwordString, user.password);
    if (!isMatch) throw new Error('Invalid email or password combination.');

    const accessToken = TokenService.generateAccessToken(user.id, user.role);
    const refreshToken = TokenService.generateRefreshToken(user.id);

    return {
      accessToken,
      refreshToken,
      user: { id: user.id, email: user.email, role: user.role, profile: user.profile }
    };
  }

  // 💡 FIXED: Real operational database handler logic for Forgot Password
  static async forgotPassword(email: string) {
    const user = await prisma.user.findUnique({ where: { email } });
    // Secure silent-return to prevent email-scraping/enumeration visibility exploits
    if (!user || user.isDeleted) return;

    const resetToken = TokenService.generateResetToken();
    const hashedResetToken = this.hashToken(resetToken);
    const expires = new Date(Date.now() + 3600000); // 1 Hour lifespan expiration boundary

    await prisma.user.update({
      where: { id: user.id },
      data: {
        passwordResetToken: hashedResetToken,
        passwordResetExpiresAt: expires
      }
    });

    const resetUrl = `${process.env.APP_URL || 'http://localhost:5173'}/auth/reset-password?token=${resetToken}`;
    const profile = await prisma.profile.findUnique({ where: { userId: user.id } });
    const recipientName = profile?.fullName || email.split('@')[0];

    try {
      await resend.emails.send({
        from: process.env.EMAIL_FROM || 'ChemEng Portal <noreply@chemengportal.com>',
        to: email,
        subject: 'Reset your password',
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #495057;">
            <h2 style="color: #1a63ef;">🧪 Password Reset Requested</h2>
            <p>Hello ${recipientName},</p>
            <p>We received a request to configure new portal access keys for your account. Click the button below to continue:</p>
            <p><a href="${resetUrl}" style="display: inline-block; background-color: #1a63ef; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold;">Reset Password</a></p>
            <p style="color: #bc2828; font-size: 13px;">⚠️ Note: This link will automatically expire in 1 hour.</p>
          </div>
        `
      });
    } catch (err) {
      console.warn('Reset link delivery skipped. Recovery Link Output:', resetUrl, err);
    }
  }

  // 💡 FIXED: Real operational database modifier logic for Reset Password
  static async resetPassword(token: string, passwordString: string) {
    const hashedToken = this.hashToken(token);

    const user = await prisma.user.findFirst({
      where: {
        passwordResetToken: hashedToken,
        passwordResetExpiresAt: { gt: new Date() } // Confirms token lifecycle is still within limits
      }
    });

    if (!user) {
      throw new Error('The password reset token is invalid or has already expired.');
    }

    const hashedPassword = await bcrypt.hash(passwordString, 12);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        passwordResetToken: null,
        passwordResetExpiresAt: null
      }
    });
  }

  static async refreshTokens(refreshToken: string) {
    try {
      const decoded = TokenService.verifyRefreshToken(refreshToken);
      const user = await prisma.user.findUnique({ where: { id: decoded.id } });
      if (!user || user.isDeleted) throw new Error('User record link broken.');

      const newAccessToken = TokenService.generateAccessToken(user.id, user.role);
      const newRefreshToken = TokenService.generateRefreshToken(user.id);

      return { accessToken: newAccessToken, refreshToken: newRefreshToken };
    } catch (error) {
      throw new Error('Refresh token session tracking expired.');
    }
  }

  // 💡 FIXED: Real operational verification handler logic for email activations
  static async verifyEmail(token: string) {
    const user = await prisma.user.findFirst({
      where: { verificationToken: token }
    });

    if (!user) {
      throw new Error('The validation channel link is invalid or has expired.');
    }

    await prisma.user.update({
      where: { id: user.id },
      data: {
        isEmailVerified: true,
        verificationToken: null
      }
    });
  }

  static async me(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        role: true,
        isEmailVerified: true,
        isDeleted: true,
        profile: true,
        createdAt: true
      }
    });
    if (!user || user.isDeleted) throw new Error('User thread data unavailable.');
    return user;
  }
}