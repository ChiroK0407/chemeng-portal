import { Request, Response, NextFunction } from 'express';

export const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized. Authentication context missing.',
    });
  }

  // Matching standard casing configurations ('admin' or 'ADMIN') safely
  if (req.user.role.toUpperCase() !== 'ADMIN') {
    return res.status(403).json({
      success: false,
      message: 'Forbidden. High-privilege administrative access required.',
    });
  }

  next();
};