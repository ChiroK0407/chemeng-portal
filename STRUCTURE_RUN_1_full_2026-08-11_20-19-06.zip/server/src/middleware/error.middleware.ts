import { Request, Response, NextFunction, ErrorRequestHandler } from 'express';
import { Prisma } from '@prisma/client';
// 1. Import the specific error class as a top-level construct
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library';
import { ZodError } from 'zod';

export const errorHandler: ErrorRequestHandler = (
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  let statusCode = err.status || 500;
  let message = err.message || 'An unexpected error occurred on the server.';
  let code = err.code || 'INTERNAL_SERVER_ERROR';
  let details: any = undefined;

  // 2. Handle Zod Schema Validation Errors
  if (err instanceof ZodError) {
    statusCode = 400;
    message = 'Data validation failed.';
    code = 'VALIDATION_ERROR';
    details = err.errors.map((e) => ({
      field: e.path.join('.'),
      message: e.message,
    }));
  }

  // 3. Handle Prisma Client Known Request Errors using the direct class import
  if (err instanceof PrismaClientKnownRequestError) {
    switch (err.code) {
      case 'P2002': // Unique constraint violation
        statusCode = 409;
        code = 'DB_UNIQUE_CONSTRAINT_VIOLATION';
        const fields = (err.meta?.target as string[]) || [];
        message = `A record with this matching identifier already exists (${fields.join(', ')}).`;
        break;
      case 'P2025': // Record not found
        statusCode = 404;
        code = 'DB_RECORD_NOT_FOUND';
        message = (err.meta?.cause as string) || 'The requested database record could not be found.';
        break;
      default:
        statusCode = 400;
        code = `PRISMA_${err.code}`;
        message = 'Database transaction sequence failed.';
        break;
    }
  }

  res.status(statusCode).json({
    success: false,
    message,
    code,
    ...(details && { details }),
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};