import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🧪 Commencing database sanitation and priming...');

  const deleteTable = async (modelName: string) => {
    try {
      if ((prisma as any)[modelName]) {
        await (prisma as any)[modelName].deleteMany({});
      }
    } catch (e) {
      // Skip quietly if names mismatch locally
    }
  };

  await deleteTable('bookmark');
  await deleteTable('notification');
  await deleteTable('resource');
  await deleteTable('resourceCategory');
  await deleteTable('opportunity');
  await deleteTable('event');
  await deleteTable('profile');
  await deleteTable('user');

  console.log('✨ Database sanitized. Provisioning initial authority node...');

  const mockHashedPassword = '$2b$10$MzYyNjI2MzYyNjI2MzYyNjI2T3VxZWNoRW5nU2VjdXJl';

  const adminUser = await (prisma.user as any).create({
    data: {
      email: 'admin@chemengportal.com',
      password: mockHashedPassword,
      role: 'admin',
    },
  });

  await (prisma.profile as any).create({
    data: {
      userId: adminUser.id,
      fullName: 'Dr. Satish Jha',
      username: 'satish_jha_che',
      bio: 'Professor of Chemical Engineering specializing in multi-phase flow hydrodynamics, Aspen Plus steady-state flowsheet synthesis, and green hydrogen scaling networks.',
      college: 'Gujarat Technological University (GTU)',
      branch: 'Chemical Engineering',
      gradYear: 1998,
      skills: ['Aspen Plus', 'MATLAB', 'Process Control', 'Mass Transfer', 'Multiphase Flow'],
      linkedinUrl: 'https://linkedin.com/in/mock-satish-jha',
      githubUrl: 'https://github.com/mock-satish-jha',
    },
  });

  console.log('⏳ Seeding core career opportunities matrix...');

  const opportunities = [
    {
      title: 'Process Simulation Engineering Intern',
      company: 'Reliance Industries Limited',
      type: 'internship',
      location: 'Jamnagar, Gujarat',
      isRemote: false,
      stipendMin: 25000,
      stipendMax: 35000,
      eligibleBranches: ['Chemical Engineering', 'Petrochemical Engineering'],
      applyUrl: 'https://careers.ril.com',
      deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 20),
    },
    {
      title: 'Junior Research Fellow (JRF) - Catalyst Synthesis',
      company: 'Indian Institute of Technology, Bombay',
      type: 'research',
      location: 'Powai, Mumbai',
      isRemote: false,
      stipendMin: 37000,
      stipendMax: 42000,
      eligibleBranches: ['Chemical Engineering', 'Material Science', 'Nanotechnology'],
      applyUrl: 'https://www.iitb.ac.in/en/careers',
      deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 10),
    },
    {
      title: 'Graduate Engineer Trainee (GET) - Plant Operations',
      company: 'Atul Limited',
      type: 'full_time',
      location: 'Valsad, Gujarat',
      isRemote: false,
      stipendMin: 55000,
      stipendMax: 65000,
      eligibleBranches: ['Chemical Engineering'],
      applyUrl: 'https://www.atul.co.in/careers',
      deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2),
    }
  ];

  for (const opp of opportunities) {
    if ((prisma as any).opportunity) {
      await (prisma as any).opportunity.create({
        data: {
          ...opp,
          status: 'published',
          postedById: adminUser.id,
        } as any,
      });
    }
  }

  console.log('⏳ Seeding technical events agenda catalog...');

  const events = [
    {
      slug: 'aspen-plus-simulation-optimization-2026',
      title: 'Aspen Plus Advanced Steady-State Flowsheet Optimization',
      status: 'upcoming',
      startsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 5),
      endsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 5 + 1000 * 60 * 60 * 3),
      isOnline: true,
      meetingUrl: 'https://teams.microsoft.com/chemeng-portal-webinar',
      maxCapacity: 150,
      description: 'This technical masterclass focuses on building high-fidelity convergence profiles inside Aspen Plus using advanced process modeling tools.'
    },
    {
      slug: 'green-hydrogen-production-process-scaling',
      title: 'Green Hydrogen Plant Scale-Up: Electrolyzer Process Architecture',
      status: 'upcoming',
      startsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14),
      endsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14 + 1000 * 60 * 60 * 2),
      isOnline: false,
      venue: 'Convention Hall B, Hazira Process Complex',
      maxCapacity: 80,
      description: 'A deep dive into the chemical process constraints of scaling PEM electrolyzers.'
    }
  ];

  for (const ev of events) {
    if ((prisma as any).event) {
      await (prisma as any).event.create({
        data: {
          ...ev,
          organizerId: adminUser.id,
        } as any,
      });
    }
  }

  console.log('⏳ Seeding academic resource hub modules...');

  let resolvedCategoryId: any = null;
  const targetCategoryClient = (prisma as any).category || (prisma as any).resourceCategory;

  if (targetCategoryClient) {
    // ✅ FIXED P2002: Replaced .create() with an .upsert() block to safely bypass unique constraint conflicts
    const catRecord = await targetCategoryClient.upsert({
      where: { slug: 'core-curriculum' },
      update: {},
      create: {
        name: 'Core Transport Phenomena & Reaction Engineering',
        slug: 'core-curriculum',
        entityType: 'resource'
      }
    });
    resolvedCategoryId = catRecord.id;
  }

  const resources = [
    {
      title: 'Mass Transfer Operations Reference Handbook',
      type: 'pdf',
      subject: 'Mass Transfer-I',
      semester: 5,
      description: 'Comprehensive analysis notes detailing sieve tray distillation hydraulics, bubble-cap tower sizing algorithms.',
      url: 'https://chemengportal-storage.s3.amazonaws.com/handbooks/mass-transfer-5.pdf',
    },
    {
      title: 'Chemical Reaction Engineering-I Video Series',
      type: 'video',
      subject: 'Chemical Reaction Engineering',
      semester: 6,
      description: 'Detailed process derivations for non-isothermal continuous stirred-tank reactor stability bounds.',
      url: 'https://www.youtube.com/playlist?list=chemeng-cre-1-portal',
    }
  ];

  for (const res of resources) {
    if ((prisma as any).resource) {
      // Clean up previous identical references if they exist before creating
      await (prisma as any).resource.deleteMany({
        where: { title: res.title }
      });

      await (prisma as any).resource.create({
        data: {
          ...res,
          categoryId: resolvedCategoryId,
          uploadedById: adminUser.id,
          status: 'published' // Ensure status defaults to visible
        } as any,
      });
    }
  }

  console.log('🚀 Database seeding pipeline executed successfully. All parameters synchronized.');
}

main()
  .catch((e) => {
    console.error('❌ Exception tracking error caught during runtime seed execution:', e);
    throw new Error('Seed run terminal loop crash handled.');
  })
  .finally(async () => {
    await prisma.$disconnect();
  });